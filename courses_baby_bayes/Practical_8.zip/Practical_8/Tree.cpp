#include "Tree.h"
#include "TreeNode.h"

#include <stdio.h>
#include <iostream>

/**
 * Constructor of the tree class.
 *
 * @param   r           The root node of the tree.
 */
Tree::Tree( TreeNode* r ) :
    root( r )
{
    
    // fill our nodes by phylogenetic traversal
    fillNodesByPhylogeneticTraversal( root );
    
    // initialize the node index
    for (size_t i=0; i<getNumberOfNodes(); i++)
    {
        nodes[i]->setIndex( i );
    }
}


/**
 * Copy constructor of the tree class.
 *
 * @param   t           The tree that we want to copy.
 */
Tree::Tree( const Tree& t ) :
    root( NULL )
{
    // only create a deep copy if the root exists
    if ( t.root != NULL )
    {
        // create a deep copy
        root = new TreeNode( *t.root );
        
        // fill our nodes by phylogenetic traversal
        fillNodesByPhylogeneticTraversal( root );
        
        // initialize the node index
        for (size_t i=0; i<getNumberOfNodes(); i++)
        {
            nodes[i]->setIndex( i );
        }
    }
    
}


/**
 * Destructor of the tree class.
 *
 * Since we own the root node, we need to free it.
 * This will also make sure that all nodes will be freed.
 *
 */
Tree::~Tree( void )
{
    // free the memory of the root node which will free the memory of all nodes recursively.
    delete root;
}


/**
 * Overloaded assignment operator.
 *
 * @param   t               The tree that we want to copy.
 * @return          The newly assigned object.
 */
Tree& Tree::operator=(const Tree &t)
{
    // first, we need to check and avoid self-assignment
    if ( this != &t )
    {

        // free the memory of the root node which will free the memory of all nodes recursively.
        delete root;
        
        // for safety, set the root to NULL
        root = NULL;
        
        nodes.clear();
        
        // only create a deep copy if the root exists
        if ( t.root != NULL )
        {
            // create a deep copy
            root = new TreeNode( *t.root );
            
            // fill our nodes by phylogenetic traversal
            fillNodesByPhylogeneticTraversal( root );
            
            // initialize the node index
            for (size_t i=0; i<getNumberOfNodes(); i++)
            {
                nodes[i]->setIndex( i );
            }
        }
        
        // we done now with our assignment
    }
        
    // we return this object now
    return *this;
}
/**
 * Compute the newick string for this tree.
 *
 * This function is a recursive function, i.e., it calls itself again.
 * You should always start with the root node when calling this function and then it terminates ones reaching the tips.
 * The newick string should be something like
 *      (((A:1.0,B:1.0):0.5,C:1.5):1.0,(D:2.0,E:2.0):2.5);
 *
 * @return          The newick string for the clade starting at this node.
 */
std::string Tree::computeNewickRecursively(const TreeNode &node, bool unique) const
{
    // initialize the newick string as an empty string
    std::string newick = "";
    
    // check if this is a tip node
    if ( node.isTip() == true )
    {
        // this is a tip node
        // so we can terminate the recursion
        // we simply have to use the name of this node for the newick string
        newick = node.getName();
    }
    else
    {
        // since it is not a tip node it must be an interior node with two children.
        // we therefore compute the newick string for both children
        // this is done with a recursive call to this function with the left and right child as an argument
        std::string left    = computeNewickRecursively( *node.getLeftChild(), unique );
        std::string right   = computeNewickRecursively( *node.getRightChild(), unique );

        // we want to print the newick trees in a unique format, so we order it alphabetically
        // hence, check if the newick string of the left child is alphabetically before the newick string of the right child.
        // we then put together the newick strings of the two children
        if ( left < right )
        {
            newick = "(" + left + "," + right + ")";
        }
        else
        {
            newick = "(" + right + "," + left + ")";
        }
    }
    if ( unique == false )
    {
        // finally, we need to add the branch length to this newick string
        newick += ":" + std::to_string(node.getBranchLength());
    }
    
    // and then we return this newick string
    return newick;
}


/**
 * Fill the nodes vector in phylogenetic ordering.
 *
 * Fill the nodes vector by a phylogenetic traversal recursively starting with this node.
 * The tips fill the slots 0,...,n-1 followed by the internal nodes and then the root.
 */
void Tree::fillNodesByPhylogeneticTraversal(TreeNode* node)
{

    if ( node->isTip() )
    {
        // all the tips go to the beginning
        nodes.insert(nodes.begin(), node);
    }
    else
    {
        // now call this function recursively for all your children
        fillNodesByPhylogeneticTraversal( node->getLeftChild() );
        fillNodesByPhylogeneticTraversal( node->getRightChild() );
        
        // this is phylogenetic ordering so the internal nodes come last
        nodes.push_back(node);
    }
}


/**
 * Compute the newick string for this tree.
 *
 * This method simply starts by traversing the tree recursively from the root.
 * See the method computeNewickRecursively for more information.
 *
 * @return          The newick string for the entire tree.
 */
std::string Tree::getNewickRepresentation( bool unique ) const
{
    
    return computeNewickRecursively( *root, unique );
}


/**
 * Get the vector with all the nodes in the tree.
 *
 * @return              The vector of nodes,
 */
const std::vector<TreeNode*> Tree::getNodes( void ) const
{
    return nodes;
}


/**
 * Get the number of nodes contained in the tree.
 *
 * This number should be 2*N-1 for rooted trees where N is the number of tips.
 *
 * @return              The number of nodes in the tree,
 */
size_t Tree::getNumberOfNodes( void ) const
{
    
    return nodes.size();
}


/**
 * Get the root node of the tree.
 *
 * @return              The root node.
 */
TreeNode* Tree::getRootNode( void )
{
    
    return root;
}


/**
 * Get the root node of the tree.
 *
 * @return              The root node.
 */
const TreeNode* Tree::getRootNode( void ) const
{
    
    return root;
}
