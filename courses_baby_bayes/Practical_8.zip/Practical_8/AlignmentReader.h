#ifndef AlignmentReader_h
#define AlignmentReader_h

#include <string>

/**
 * \class AlignmentReader
 *
 * \brief A reader for alignments from files in different formats.
 *
 * This class provides the functionality of a reader for alignments.
 * The alignments will be read from file. Currently, we support only
 * the Phylip data format.
 *
 *
 * \author Sebastian Höhna
 *
 */
class AlignmentReader {
    
public:
    AlignmentReader(void);
    ~AlignmentReader(void);
    
    Alignment                           readPhylip(const std::string &fn);
    
};


#endif /* Alignment_h */
