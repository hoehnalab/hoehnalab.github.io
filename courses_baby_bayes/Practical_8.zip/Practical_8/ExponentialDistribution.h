#ifndef ExponentialDistribution_h
#define ExponentialDistribution_h

#include <stdio.h>

#include "RandomNumberGenerator.h"

class ExponentialDistribution {

public:
    ExponentialDistribution(const double* l);
    virtual                    ~ExponentialDistribution();

    double                      lnProbability(void) const ;
    double*                     rv(RandomNumberGenerator* rng);
    void                        setValue(const double *x);

protected:

    const double*               lambda;
    const double*               value;

};


#endif /* ExponentialDistribution_hpp */
