#ifndef NormalDistribution_h
#define NormalDistribution_h

#include <stdio.h>

#include "RandomNumberGenerator.h"

class NormalDistribution {

public:
    NormalDistribution(const double* m, const double* s);
    virtual                    ~NormalDistribution();

    double                      lnProbability(void) const ;
    double*                     rv(RandomNumberGenerator* rng);
    void                        setValue(const double *x);

protected:

    const double*               mu;
    const double*               sigma;
    const double*               value;

};


#endif /* NormalDistribution_h */
