#include "PureBirthProcess.h"

#include "Tree.h"
#include "TreeNode.h"

#include <cmath>

/**
 * Constructor of the PureBirthProcess.
 *
 * @param   n           The taxon names used for the tips.
 * @param   b           The birth rate parameter.
 */
PureBirthProcess::PureBirthProcess(const std::vector<std::string> &n, const double *b) :
    taxon_names( n ),
    birth_rate( b )
{

}


/**
 * Destructor of the pure birth process.
 */
PureBirthProcess::~PureBirthProcess( void )
{
    // we do not own the rate parameter nor the value, so we have nothing to delete
}


/**
 * Compute the log-probability of the values given the birth rate.
 *
 * The algorithm here is to get all branches of the tree and compute the
 * probability of nothing happening along the branch and the
 * speciation/birth event at the end of the branch.
 *
 * @return              Returns the log-probability.
 */
double PureBirthProcess::lnProbability( void ) const
{
    // initialize the log probability
    double ln_prob = 0.0;

    // for simplicity of use, store the birth-rate as a local double variable
    double l = *birth_rate;

    // get all the nodes of the tree
    const std::vector<TreeNode*> &nodes = value->getNodes();

    // iterate over all the nodes to get the branch lengths
    for (size_t i=0; i<nodes.size(); i++)
    {
        // get the current node
        TreeNode *node = nodes[i];

        // make sure that it is not the root node
        if ( node->isRoot() == false )
        {
            // get the current branch length
            double bl = node->getBranchLength();
            // add the log-probability of no event along the branch (-l*bl)
            ln_prob -= l * bl;

            if ( node->isTip() == false )
            {
                // the log-probability density for the event itself (l)
                ln_prob += std::log(l);

            }
        }

    } // end for loop over all nodes

    // return the computed log probability
    return ln_prob;
}


/**
 * Draw a random tree from a birth death process.
 *
 * @param   rng         The random number generator used for the simulation.
 * @return              The random tree.
 */
Tree* PureBirthProcess::rv(RandomNumberGenerator *rng)
{
    // prepare some variables, such as the birth rate
    double l = *birth_rate;
    double num_taxa = taxon_names.size();

    // now we need some helper vectors with the active and inactive nodes
    std::vector<TreeNode*> active;
    std::vector<TreeNode*> inactive;
    std::vector<double> times;

    // we also start our simulation with the root node
    // this means that we create the root node and the two children of it
    TreeNode *root = new TreeNode();
    TreeNode *left = new TreeNode();
    left->setParent( root );
    root->setLeftChild( left );
    TreeNode *right = new TreeNode();
    right->setParent( root );
    root->setRightChild( right );

    // now we also know that the age of the root was the age for the simulation
//    root->setAge( age );

    // add the two children of the root to the active list and the root to the inactive list
    active.push_back(left);
    active.push_back(right);
    inactive.push_back(root);
    times.push_back( 0.0 );

    // now we simulate until we reached the present time (a time of 0)
    // so we initialize the current time variable with the age of the tree
    double current_time = 0.0;
    while ( active.size() < taxon_names.size() )
    {
        // randomly draw a new speciation event
        double rate = l*active.size();
        double u = rng->uniform01();
        double next_time = current_time - (1.0/rate) * std::log(u);
        times.push_back( next_time );

//        // make sure that the next speciation time was not in the future
//        if ( next_time < 0 )
//        {
//            break;
//        }

        // randomly pick a node that speciated
        size_t index = rng->uniform01() * active.size();
        TreeNode *node = active[index];

//        // set the age of the speciation event
//        node->setAge( next_time );

        // add new descendants to the node
        TreeNode *left = new TreeNode();
        left->setParent( node );
        node->setLeftChild( left );
        TreeNode *right = new TreeNode();
        right->setParent( node );
        node->setRightChild( right );


        // remove the current node and add it's two children to our active list
        active.erase( active.begin() + index );
        active.push_back( left );
        active.push_back( right );

        // for later use, store the current node
        inactive.push_back( node );

        // update the current time with the time of the next birth event
        current_time = next_time;

    } // end while loop until the end of time

    double rate = l*active.size();
    double u = rng->uniform01();
    double next_event = -(1.0/rate) * std::log(u);
    double v = rng->uniform01();
    double tree_age = current_time + next_event*v;

    // set the indices of the simulated
    for ( size_t i=0; i<inactive.size(); i++ )
    {
        TreeNode *node = inactive[i];
        node->setAge( tree_age - times[i] );
        node->setIndex( 2*num_taxa-2-i );
    }

    // now also set the tip names
    for ( size_t i=0; i<taxon_names.size(); i++ )
    {

        // randomly pick a node
        size_t index = rng->uniform01() * active.size();
        TreeNode *node = active[index];
        active.erase( active.begin() + index );

        node->setIndex( i );
        node->setName( taxon_names[i] );
    }

    // finally, we create our tree object by passing in the root node
    Tree *t = new Tree( root );

    // and return the new tree
    return t;
}


void PureBirthProcess::setValue(const Tree *t)
{
    value = t;
}
