#include "RateMatrix_F81.h"

#include <cmath>


/**
 * Constructor of the Jukes-Cantor Rate Matrix class.
 *
 * There are no variables that need to be initialized.
 *
 */
RateMatrix_F81::RateMatrix_F81( const std::vector<double>* p ) :
  pi( p )
{

}


/**
 * Destructor.
 *
 * Since we do not have any member variables, there is no memory to free here.
 *
 */
RateMatrix_F81::~RateMatrix_F81( void )
{

}


/**
 * Calculate the transition probabilities.
 *
 * The transition probabilies are computed as
 *  for off diagonals:      1/4 - 1/4 * exp(-v*4/3)
 *  for diagonals:          1/4 + 3/4 * exp(-v*4/3)
 * Where v = t * r
 *
 * @param   time            The branch time (t) for which to compute the transition probabilities (bl = t * r).
 * @param   rate            The branch rate (r) for which to compute the transition probabilities (bl = t * r).
 * @return                  The transition probability matrix.
 */
std::vector<std::vector<double> > RateMatrix_F81::calculateTransitionProbabilities(double time, double rate) const
{

    size_t num_states = 4;

    std::vector<std::vector<double> > P = std::vector<std::vector<double> >(num_states, std::vector<double>(num_states, 0.0));

    double v = rate * time;

    // calculate the transition probabilities
    double tmp = 1.0;
    for ( size_t i=0; i<num_states; i++ ) tmp -= ((*pi)[i]*(*pi)[i]);
    double beta = 1/tmp;

    for (size_t i=0; i<num_states; i++)
    {
        // P[i][i] = p_ii;
        for (size_t j=0; j<num_states; j++)
        {
            if ( i == j)
            {
              P[i][j] = exp(-v * beta) + ((*pi)[j]) * (1.0-exp(-v * beta));
            }
            else
            {
              P[i][j] = ((*pi)[j])*(1.0-exp(-v * beta));
            }

        }

    }

    return P;
}
