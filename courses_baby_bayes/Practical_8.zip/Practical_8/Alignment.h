#ifndef Alignment_h
#define Alignment_h

#include <stdio.h>
#include <string>
#include <vector>

/**
 * \class Alignment
 *
 * \brief Represents the multiple sequence alignment class holding the data matrix.
 *
 * This class represent the multiple sequence alignment.
 * It's main purpose is to hold and manage the character data matrix.
 *
 *
 * \author Sebastian Höhna
 *
 */
class Alignment {

public:

    Alignment(size_t nt, size_t ns);
    ~Alignment(void);

    char                                getNucleotide(size_t i, size_t j) const;
    size_t                              getNumberOfSites(void) const;
    size_t                              getNumberOfTaxa(void) const;
    const std::vector<std::string>&     getTaxonNames(void) const;
    std::vector<int>                    getNucleotideStates (char nuc) const;
    void                                print(std::ostream & o) const;
    void                                setMatrix(const std::vector<std::vector<char> > &m);
    void                                setNucleotide(char x, size_t i, size_t j);
    void                                setTaxonNames(const std::vector<std::string> &n);

private:

    size_t                              num_taxa;
    size_t                              num_sites;
    std::vector<std::string>            taxon_names;
    std::vector<std::vector<char> >     data_matrix;

};



#endif /* Alignment_h */
