#include "NormalDistribution.h"
#include "MathConstants.h"

#include <cmath>

NormalDistribution::NormalDistribution(const double *m, const double* sd) :
    mu( m ),
    sigma( sd )
{

}


NormalDistribution::~NormalDistribution( void )
{
    // we do not own the value, so we do not delete it

}

double NormalDistribution::lnProbability( void ) const
{
    
    double mean = *mu;
    double sd   = *sigma;
    double x    = *value;
    
    return - Constants::LN_SQRT_2PI - std::log(sd) - 0.5 * (x - mean) * (x - mean) / (sd * sd);
}


double* NormalDistribution::rv(RandomNumberGenerator *rng)
{
    
    double mean = *mu;
    double sd   = *sigma;
    
    double v1 = 0.0;
    double v2 = 0.0;
    
    double rsq = 0.0;
    do
    {
        v1 = 2.0 * rng->uniform01() - 1.0;
        v2 = 2.0 * rng->uniform01() - 1.0;
        rsq = v1 * v1 + v2 * v2;
    } while ( rsq >= 1.0 || rsq == 0.0 );
    double fac = sqrt(-2.0 * log(rsq)/rsq);
    return new double( mean + sd * (v2 * fac) );
}


void NormalDistribution::setValue(const double *v)
{
    value = v;
}
