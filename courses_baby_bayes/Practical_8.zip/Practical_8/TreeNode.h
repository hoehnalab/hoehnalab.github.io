#ifndef TreeNode_h

#include <string>


/**
 * \class TreeNode
 *
 * \brief The node class used in phylogenetic tree.
 *
 * This class represent a tree node of a phylogenetic tree.
 * Here we store the main structure of the trees and all necessary methods.
 *
 *
 * \author Sebastian Höhna
 *
 */
class TreeNode {
    
public:
    TreeNode(void);
    TreeNode(const TreeNode& tn);
    ~TreeNode(void);
    
    TreeNode&                           operator=(const TreeNode& tn);
    
    double                              getAge(void) const;
    double                              getBranchLength(void) const;
    int                                 getIndex(void) const;
    const TreeNode*                     getLeftChild(void) const;
    TreeNode*                           getLeftChild(void);
    const std::string&                  getName(void) const;
    const TreeNode*                     getParent(void) const;
    TreeNode*                           getParent(void);
    const TreeNode*                     getRightChild(void) const;
    TreeNode*                           getRightChild(void);
    bool                                isRoot(void) const;
    bool                                isTip(void) const;
    void                                setAge(double a);
    void                                setLeftChild(TreeNode *n);
    void                                setIndex(size_t i);
    void                                setName(const std::string& n);
    void                                setParent(TreeNode* n);
    void                                setRightChild(TreeNode* n);

private:
    
    TreeNode*                           parent;
    TreeNode*                           left;
    TreeNode*                           right;
    
    int                                 index;
    double                              age;
    std::string                         name;
};

#endif /* TreeNode_h */
