#include "RandomNumberGenerator.h"


/**
 * Constructor for RandomNumberGenerator class. This constructor does not take
 * any parameters and initializes the seed using the current
 * system time.
 *
 */
RandomNumberGenerator::RandomNumberGenerator(void)
{
    
    // initialize the seed with the system time
    setSeed();
    
}

/**
 * Constructor for RandomNumberGenerator class which takes as a
 * parameter a long integer with the user-supplied seed for the
 * random number generator.
 *
 * @param   x           is a long integer with the user-supplied random number seed.
 */
RandomNumberGenerator::RandomNumberGenerator(unsigned int x)
{

    setSeed(x, 0);

}


/**
 * This function sets the two seeds for the random number generator, using the current time.
 *
 *
 */
void RandomNumberGenerator::setSeed(void)
{
    
    unsigned int x = (unsigned int)( time( 0 ) );
    seed1 = x & 0xFFFF;
    seed2 = x >> 16;
    
}

/**
 * This function sets the two seeds for the random number generator.
 * If only one starting value is given we set the two seeds by
 * using the two least signficant bytes as one seed
 * and the two most significant bytes shifted to the right as the second seed.
 *
 * @param   s1           first seed.
 * @param   s2           second seed.
 */
void RandomNumberGenerator::setSeed(unsigned int s1, unsigned int s2)
{
    if (s1 == 0)
    {
        setSeed();
    }
    else if(s2 == 0)
    {
        seed1 = s1&0xFFFF;
        seed2 = s1>>16;
    }
    else
    {
        seed1 = s1;
        seed2 = s2;
    }
    
}


/**
 * This function generates a uniformly-distributed random variable on the interval [0,1).
 * It is a version of the Marsaglia Multi-Carry.
 *
 * Taken from:
 *   Mathlib : A C Library of Special Functions
 *   Copyright (C) 2000, 2003  The R Development Core Team
 *
 * This random generator has a period of 2^60, which ensures it has the maximum
 * period of 2^32 for unsigned ints (32 bit ints).
 *
 * @return                  Returns a uniformly-distributed random variable on the interval [0,1).
 *
 * @see http://stat.fsu.edu/~geo/diehard.html
 */
double RandomNumberGenerator::uniform01(void)
{
    
    // Returns a pseudo-random number between 0 and 1.
    seed1 = 36969 * (seed1 & 0177777) + (seed1 >> 16);
    seed2 = 18000 * (seed2 & 0177777) + (seed2 >> 16);
    return (((seed1 << 16)^(seed2 & 0177777)) * 2.328306435996595e-10) +  2.328306437080797e-10 ;
}
