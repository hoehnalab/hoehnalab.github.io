#ifndef RandomNumberGenerator_h
#define RandomNumberGenerator_h

#include <stdio.h>

#include <vector>

class RandomNumberGenerator {
        
public:
        
    RandomNumberGenerator(void);
    RandomNumberGenerator(unsigned int x);

    // Regular functions
    void                                setSeed(void);
    void                                setSeed(unsigned int seed1, unsigned int seed2);
    double                              uniform01(void);
        
private:
    unsigned int                        seed1, seed2;
        
};

#endif /* RandomNumberGenerator_h */
