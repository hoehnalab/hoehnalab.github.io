#ifndef RateMatrix_F81_h
#define RateMatrix_F81_h

#include <stdio.h>
#include <vector>

/**
 * \class RateMatrix_F81
 *
 * \brief Represents the rate matrix class for the Felsenstein (1981) model.
 *
 * This class provides the transition probability calculation using for the Felsenstein (1981) rate matrix.
 * The purpose is simply to calculate these transition probabilities for a given branch length.
 * For the F81 rate matrix we know the analytical solution for the transition probabilities.
 * The F81 has no parameter but can be applied to any number of states.
 * The resulting rate matrix is computed by:
 *
 *      |  -     pi_C   pi_G   pi_T  |
 *      |                            |
 *      | pi_A    -     pi_G   pi_T  |
 * Q =  |                            |
 *      | pi_A   pi_C    -     pi_T  |
 *      |                            |
 *      | pi_A   pi_C   pi_G    -    |
 *
 *
 * \author Sebastian Höhna
 *
 */
class RateMatrix_F81 {

public:

    RateMatrix_F81(const std::vector<double>* p);
    virtual                                        ~RateMatrix_F81();

    std::vector<std::vector<double> >               calculateTransitionProbabilities(double time, double rate) const;       //!< Calculate the transition matrixmatrix

private:
    const std::vector<double>*                      pi;       //!< Calculate the transition matrixmatrix

};

#endif /* RateMatrix_F81_h */
