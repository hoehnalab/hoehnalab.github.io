#include "MCMC.h"

#include <math.h>       /* isnan, sqrt */
#include <cmath>        /* std::exp */

#include "Tree.h"
#include "TreeNode.h"
#include "TreeSummary.h"


MCMC::MCMC( const std::string &filename ) :
    my_model( filename ),
    parameter_file( "my_analysis.log" ),
    tree_file( "my_analysis.trees" )
{
    parameter_file << "Iteration";
    parameter_file << "\t";
    parameter_file << "Likelihood";
    parameter_file << "\t";
    parameter_file << "Speciation";
    parameter_file << "\t";
    parameter_file << "Clock";
    parameter_file << "\t";
    parameter_file << "Root";
    parameter_file << std::endl;

}

MCMC::MCMC( const MCMC &m ) :
    my_model( "" ),
    parameter_file( "my_analysis.log" ),
    tree_file( "my_analysis.trees" )
{
    parameter_file << "Iteration";
    parameter_file << "\t";
    parameter_file << "Likelihood";
    parameter_file << "\t";
    parameter_file << "Speciation";
    parameter_file << "\t";
    parameter_file << "Clock";
    parameter_file << "\t";
    parameter_file << "Root";
    parameter_file << std::endl;

}


MCMC::~MCMC( void )
{
    // nothing to do here
}



void MCMC::monitorParameters( int gen )
{
    parameter_file << gen;
    parameter_file << "\t";
    parameter_file << my_model.getLikelihood();
    parameter_file << "\t";
    parameter_file << my_model.getBirthRate();
    parameter_file << "\t";
    parameter_file << my_model.getClockRate();
    parameter_file << "\t";
    parameter_file << my_model.getTree()->getRootNode()->getAge();
    parameter_file << std::endl;

    tree_file << my_model.getTree()->getNewickRepresentation(false);
    tree_file << std::endl;
}

void MCMC::updateBirthRate( void )
{
    // get the current birth rate
    double current_rate = my_model.getBirthRate();

    // draw a new random uniform number
    double u = rng.uniform01();

    // define the window size
    double delta = 0.2;

    // now we compute the new proposed values
    double new_rate = current_rate + (u-0.5) * delta;

    // compute the prior ratio and likelihood ratio
    double current_prior = my_model.getBirthRatePrior();
    double current_likelihood = my_model.getTreePrior();

    // set the new value
    my_model.setBirthRate( new_rate );

    double new_prior = my_model.getBirthRatePrior();
    double new_likelihood = my_model.getTreePrior();

    double acceptance_prob = new_prior - current_prior + new_likelihood - current_likelihood;

    u = log( rng.uniform01()) ;

    if ( isnan(acceptance_prob) || u > acceptance_prob )
    {
        // reject -> reset the value
        my_model.setBirthRate( current_rate );
    }
    else
    {
        // accept! nothing to do, because we changed our value already
    }


}



void MCMC::updateClockRate( void )
{

    // get the current birth rate
    double current_rate = my_model.getClockRate();

    // draw a new random uniform number
    double u = rng.uniform01();

    // define the window size
    double delta = 0.2;

    // compute the new scaling factor
    double sf = std::exp( delta * ( u - 0.5 ) );

    // now we compute the new proposed values
    double new_rate = current_rate * sf;

    // compute the prior ratio and likelihood ratio
    double current_prior = my_model.getClockRatePrior();
    double current_likelihood = my_model.getLikelihood();

    // set the new value
    my_model.setClockRate( new_rate );

    double new_prior = my_model.getClockRatePrior();
    double new_likelihood = my_model.getLikelihood();

    // compute the Hastings ratio
    double ln_hastings_ratio = log( sf );

    double acceptance_prob = new_prior - current_prior + new_likelihood - current_likelihood + ln_hastings_ratio;

    u = log( rng.uniform01() );

    if ( isnan(acceptance_prob) || u > acceptance_prob )
    {
        // reject -> reset the value
        my_model.setClockRate( current_rate );
    }
    else
    {
        // accept! nothing to do, because we changed our value already
    }

}


void MCMC::run( int num_generations )
{
    // we assume that the model and all parameters are initialized.

    int thinning = 10;

    int runtime_start = (int)time(NULL);

    for ( int current_gen=0; current_gen<=num_generations; current_gen++ )
    {
        // draw new values:
        updateBirthRate();

        updateClockRate();

        updateNodeAges();
        updateRootAge();
        updateTopologyNNI();

        // now we monitor the variables
        if ( current_gen % thinning == 0 )
        {
            monitorParameters( current_gen );
        }
        if ( current_gen % 1000 == 0 )
        {
            std::cerr << std::setw(6) << current_gen << " -- " << std::fixed << std::setprecision(3) << my_model.getLikelihood() << std::endl;
        }

    }

    int runtime_end = (int)time(NULL);
    std::cout << "   Markov chain completed in " << (static_cast<float>(runtime_end - runtime_start)) << " seconds" << std::endl;

    std::cout << "Hooray, we finished our MCMC run!" << std::endl;


    TreeSummary trees = TreeSummary( "my_analysis.trees" );
    trees.summarize( 0.2 );
}
