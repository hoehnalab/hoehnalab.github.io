#include "Model.h"

#include "Alignment.h"
#include "AlignmentReader.h"
#include "ExponentialDistribution.h"
#include "NewickTreeReader.h"
#include "NormalDistribution.h"
#include "PhyloCTMC.h"
#include "PureBirthProcess.h"
#include "RateMatrix_JC.h"
#include "Tree.h"
#include "TreeNode.h"
#include "UniformDistribution.h"


Model::Model(const std::string &fn)
{
    // read in some trees
    NewickTreeReader tree_reader = NewickTreeReader();
    std::vector<Tree> trees = tree_reader.readTrees("primates.tre");
    my_tree = new Tree(trees[0]);

    // read in the data (i.e., the alignment)
    AlignmentReader reader;
    Alignment* my_alignment = new Alignment( reader.readPhylip( fn ) );


    // create a transition rate matrix
    my_rate_matrix = new RateMatrix_JC();

    // create the clock rate prior
    double* min_clock_rate = new double(0.0);
    double* max_clock_rate = new double(100.0);
    clock_rate_prior = new UniformDistribution(min_clock_rate, max_clock_rate);

    my_clock_rate = new double(0.01);
    clock_rate_prior->setValue( my_clock_rate );

    // now set up the tree prior
    double* birth_rate_mean = new double(1.0);
    birth_rate_prior = new ExponentialDistribution(birth_rate_mean);

    // now set up the root prior
    double* root_mean = new double(75.0);
    double* root_sd   = new double(2.5);
    root_prior = new NormalDistribution(root_mean,root_sd);
    root_prior->setValue( new double(my_tree->getRootNode()->getAge() ) );

    // specify the birth rate
    my_birth_rate = new double(1.0);
    birth_rate_prior->setValue( my_birth_rate );

    tree_prior = new PureBirthProcess( my_alignment->getTaxonNames(), my_birth_rate );
    tree_prior->setValue( my_tree );

    likelihood = new PhyloCTMC( my_tree, my_rate_matrix, my_clock_rate );
    likelihood->setValue( my_alignment );

}

Model::~Model()
{
    delete my_alignment;
    delete my_birth_rate;
    delete my_clock_rate;
    delete my_rate_matrix;
    delete my_tree;

    delete tree_prior;
    delete birth_rate_prior;
    delete clock_rate_prior;
    delete likelihood;
}


double Model::getBirthRate(void) const
{
    return *my_birth_rate;
}


double Model::getBirthRatePrior(void)
{
    return birth_rate_prior->lnProbability();
}


double Model::getClockRate(void) const
{
     return *my_clock_rate;
}


double Model::getClockRatePrior(void)
{
    return clock_rate_prior->lnProbability();
}


double Model::getLikelihood(void)
{
    return likelihood->lnProbability();
}


Tree* Model::getTree(void) const
{
    return my_tree;
}


double Model::getTreePrior(void)
{
    return tree_prior->lnProbability();
}


double Model::getRootPrior(void)
{
    root_prior->setValue( new double(my_tree->getRootNode()->getAge() ) );
    return root_prior->lnProbability();
}


void Model::setBirthRate( double r )
{
    *my_birth_rate = r;
}


void Model::setClockRate( double r )
{
    *my_clock_rate = r;
}
