#include <iostream>     // for std::cerr
#include <sstream>      // for splitting strings
#include <fstream>      // for reading from a file

#include <string>
#include <vector>

#include <iterator>     // std::istream_iterator

#include "Alignment.h"
#include "AlignmentReader.h"


/**
 * A default constructor that does nothing besides creating an object of this class.
 */
AlignmentReader::AlignmentReader( void )
{
    // nothing to initialize
}


/**
* A default destructor that does nothing because we don't have any allocated variables.
*/
AlignmentReader::~AlignmentReader( void )
{
    // nothing to delete here
}


Alignment AlignmentReader::readPhylip(const std::string& fn)
{
    
    // first, we open the file stream
    // this uses a ifstream object and needs the filesname
    std::ifstream in_stream(fn);
    // let's see if the stream was opened
    if (!in_stream)
    {
        // it was not opened, so the file did not exist
        // we need to tell the user and terminate
        std::cerr << "Cannot open file \"" + fn + "\"" << std::endl;
        exit(1);
    }
    
    // now we can initialize some helper variables
    // we a string for the current line of the file
    std::string linestring = "";
    // we also need the current taxon number
    size_t taxon_num = 0;
    // the number of taxa
    size_t num_taxa = 0;
    // the number of sites
    size_t num_sites = 0;
    // and if all the taxon names have been read in
    bool taxon_names_read = false;
    // finally we also need a vector of strings for the taxon names
    std::vector<std::string> taxon_names;
    
    // first, we need to read the number of taxa and sites
    // this should be the first line, so we load the first line into the linestring variable
    getline(in_stream, linestring);
    
    // now we split the line into tokens separated by a white space
    // this assumme that the number of taxa and sites are provided in this line with only whitespaces separating them
    // we create stringstream for this
    std::istringstream word_iss(linestring);
    // and then separate the line by whitespaces
    std::vector<std::string> words((std::istream_iterator<std::string>(word_iss)),
                                    std::istream_iterator<std::string>());
    
    // now we store the number of taxa and sites into our variables
    num_taxa = std::stoi( words[0] );
    num_sites = std::stoi( words[1] );
    // with these two, we can now create our alignment
    Alignment this_alignment = Alignment(num_taxa, num_sites);
    // for the actual data, and for convenience, we create a data matrix that has num_taxa rows but no columns yet
    std::vector<std::vector<char> > matrix = std::vector<std::vector<char> >( num_taxa, std::vector<char>() );
    
    // then we start to loop over the entire file
    // we do this with an endless loop which we will stop when the end of file has been reached.
    while ( true )
    {
        // first, check if there are more lines to be read
        bool more_lines_in_file = getline(in_stream, linestring).good();
        // then, we skip forward over any empty line
        while ( more_lines_in_file && linestring == "" )
        {
            // check again if we reached the end of file
            more_lines_in_file = getline(in_stream, linestring).good();
        }
        // if we reached the end of the file, then we should break out of endless loop
        if ( more_lines_in_file == false )
        {
            // this break command stops the endless loop
            break;
        }
        
        // now we split the line by whitespaces using again a stringstream
        std::istringstream iss(linestring);
        std::vector<std::string> tokens((std::istream_iterator<std::string>(iss)),
                                        std::istream_iterator<std::string>());
        
        // we then iterate over all the tokens/words that we received.
        for ( int i=0; i<tokens.size(); i++ )
        {
            // the first word should be the taxon name
            // this should only be done if we haven't read all taxon names in interleaved file format
            if ( i == 0 && taxon_names_read == false )
            {
                // so we push the first word to the end of the names of the taxa
                taxon_names.push_back(tokens[i]);
            }
            else
            {
                // otherwise, we have an actual sequence
                const std::string &the_sequence = tokens[i];
                // so we add the sequence to the end of the sequence for this taxon
                // thus, we append our data matrix using the insert function
                matrix[taxon_num].insert(matrix[taxon_num].end(), the_sequence.begin(), the_sequence.end());
            }
        }
        
        // since we finished we this line, we need to move on to the next taxon.
        taxon_num++;
        // if we have finished with all taxa, then we start with the first one again (for interleaved files)
        if ( taxon_num == num_taxa )
        {
            // hence, set the taxon index to 0 (we start counting with 0)
            taxon_num = 0;
            // and remember that we read all taxon names
            taxon_names_read = true;
        }
        
    } // the end of our while ( true ) loop
    
    
    // always remember to close the file
    in_stream.close();
    
    // now we propagate the taxon names and data matrix into our alignment
    this_alignment.setTaxonNames( taxon_names );
    this_alignment.setMatrix( matrix );
    
    // and finally return this new alignment
    return this_alignment;
}
