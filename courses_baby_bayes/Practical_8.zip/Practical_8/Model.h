#ifndef Model_h
#define Model_h

#include <stdio.h>
#include <vector>

// forward declarations
class Alignment;
class ExponentialDistribution;
class NormalDistribution;
class PhyloCTMC;
class PureBirthProcess;
class RateMatrix_JC;
class Tree;
class UniformDistribution;

/**
 * \class Model
 *
 * \brief This class represents the phylogenetic model.
 *
 *
 *
 * \author Sebastian Höhna
 *
 */
class Model {

public:

    Model(const std::string &fn);
    virtual                                        ~Model();

    // parameters
    double                                          getBirthRate(void) const;
    double                                          getClockRate(void) const;
    Tree*                                           getTree(void) const;

    void                                            setBirthRate( double r );
    void                                            setClockRate( double r );
//    void                                            setRateMatrix( RateMatrix_JC* q );

    // distributions
    double                                          getBirthRatePrior(void);
    double                                          getClockRatePrior(void);
    double                                          getLikelihood(void);
    double                                          getRootPrior(void);
    double                                          getTreePrior(void);

private:

    Alignment*                                      my_alignment;
    double*                                         my_birth_rate;
    double*                                         my_clock_rate;
    RateMatrix_JC*                                  my_rate_matrix;
    Tree*                                           my_tree;

    ExponentialDistribution*                        birth_rate_prior;
    UniformDistribution*                            clock_rate_prior;
    NormalDistribution*                             root_prior;
    PureBirthProcess*                               tree_prior;
    PhyloCTMC*                                      likelihood;


};

#endif /* Model_h */
