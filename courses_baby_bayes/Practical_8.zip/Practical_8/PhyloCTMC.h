#ifndef PhyloCTMC_h
#define PhyloCTMC_h

#include "RandomNumberGenerator.h"

#include <stdio.h>
#include <vector>

// forward declaration(s)
class Alignment;
class RateMatrix_JC;
class Tree;
class TreeNode;


typedef std::vector< std::vector< std::vector< std::vector<double> > > > LikelihoodVector;
//typedef std::vector< std::vector< std::vector< std::vector< std::vector<double> > > > > LikelihoodVector;

/**
 * \class PhyloCTMC
 *
 * \brief A Continuous Time Markov chain (CTMC) process for simulating alignments and computing probabilities.
 *
 * This class represents a CTMC process along a phylogeny.
 * This class contains the main probability an likelihood computation function.
 *
 *
 * \author Sebastian Höhna
 *
*/
class PhyloCTMC {

public:
    PhyloCTMC(const Tree* phy, const RateMatrix_JC* q, const double* clock_rate);
    virtual                    ~PhyloCTMC();

    double                                  lnProbability(void) const ;
    Alignment*                              rv(RandomNumberGenerator *rng);
    void                                    setValue(const Alignment *x);

private:

    void                                    computeLnLikelihoodRecursively(const TreeNode* n) const;
    std::vector<std::vector<double> >       computeTransitionProbabilityMatrix(const TreeNode* n) const;
    void                                    initializeConditionalLikelihoods(void);
    void                                    simulateAlignmentRecursively( std::vector<std::vector<char> >& m,
                                                                          const std::vector<char>& ps,
                                                                          const TreeNode* n,
                                                                          RandomNumberGenerator *rng );



    mutable std::vector<size_t>             active_likelihood_index;
    mutable LikelihoodVector                conditional_likelihoods;
//    size_t                                  num_gamma_categories;
    size_t                                  num_states;


    const Tree*                             phylogeny;
    const RateMatrix_JC*                    Q;
    const double*                           clock_rate;
    const Alignment*                        value;

};

#endif /* PhyloCTMC_h */
