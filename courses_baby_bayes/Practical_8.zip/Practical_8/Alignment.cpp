#include "Alignment.h"

#include <iostream>
#include <iomanip>

/**
 * Constructor of the alignment class.
 * We will construct an empty data matrix of size nt rows and nc columns.
 *
 * @param    nt     number of taxa/rows in the alignment
 * @param    ns     number of sites/characters/columns in the alignment
 */
Alignment::Alignment( size_t nt, size_t ns ) :
    num_taxa( nt ),
    num_sites( ns )
{
    // create an empty data matrix of num_taxa rows and num_sites columns.
    // By default we set every entry to '?', the missing character
    data_matrix = std::vector<std::vector<char> >(num_taxa, std::vector<char>(num_sites, '?'));
}

/**
 * Desctructor of the alignment class.
 *
 * Since we don't have any allocated memory we don't need to free any.
 */
Alignment::~Alignment( void )
{
    // nothing to do in here.
}


/*-------------------------------------------------------------------
 |
 |   GetPossibleNucs:
 |
 |   This function initializes a vector, nuc[MAX_NUM_STATES]. The four elements
 |   of nuc correspond to the four nucleotides in alphabetical order.
 |   We are assuming that the nucCode is a binary representation of
 |   the nucleotides that are consistent with the observation. For
 |   example, if we observe an A, then the nucCode is 1 and the
 |   function initalizes nuc[0] = 1 and the other elements of nuc
 |   to be 0.
 |
 |   Observation    nucCode        nuc
 |        A            1           1000
 |        C            2           0100
 |        G            4           0010
 |        T            8           0001
 |        R            5           1010
 |        Y           10           0101
 |        M            3           1100
 |        K           12           0011
 |        S            6           0110
 |        W            9           1001
 |        H           11           1101
 |        B           14           0111
 |        V            7           1110
 |        D           13           1011
 |        N - ?       15           1111
 |
 -------------------------------------------------------------------*/
std::vector<int> Alignment::getNucleotideStates (char nuc) const
{

    std::vector<int> states(4,0);

    switch ( nuc )
    {
        case 'A':
            states[0] = 1;
            states[1] = 0;
            states[2] = 0;
            states[3] = 0;
            break;
        case 'C':
            states[0] = 0;
            states[1] = 1;
            states[2] = 0;
            states[3] = 0;
            break;
        case 'M':
            states[0] = 1;
            states[1] = 1;
            states[2] = 0;
            states[3] = 0;
            break;
        case 'G':
            states[0] = 0;
            states[1] = 0;
            states[2] = 1;
            states[3] = 0;
            break;
        case 'R':
            states[0] = 1;
            states[1] = 0;
            states[2] = 1;
            states[3] = 0;
            break;
        case 'S':
            states[0] = 0;
            states[1] = 1;
            states[2] = 1;
            states[3] = 0;
            break;
        case 'V':
            states[0] = 1;
            states[1] = 1;
            states[2] = 1;
            states[3] = 0;
            break;
        case 'T':
            states[0] = 0;
            states[1] = 0;
            states[2] = 0;
            states[3] = 1;
            break;
        case 'W':
            states[0] = 1;
            states[1] = 0;
            states[2] = 0;
            states[3] = 1;
            break;
        case 'Y':
            states[0] = 0;
            states[1] = 1;
            states[2] = 0;
            states[3] = 1;
            break;
        case 'H':
            states[0] = 1;
            states[1] = 1;
            states[2] = 0;
            states[3] = 1;
            break;
        case 'K':
            states[0] = 0;
            states[1] = 0;
            states[2] = 1;
            states[3] = 1;
            break;
        case 'D':
            states[0] = 1;
            states[1] = 0;
            states[2] = 1;
            states[3] = 1;
            break;
        case 'B':
            states[0] = 0;
            states[1] = 1;
            states[2] = 1;
            states[3] = 1;
            break;
        case '?':
        case '-':
        case 'N':
            states[0] = 1;
            states[1] = 1;
            states[2] = 1;
            states[3] = 1;
    }

    return states;
}


/**
 * Get the character for the i-th taxon/row and j-th site/column.
 *
 *
 * @param   i           the i-th taxa in the alignment
 * @param   j           the j-th site in the alignment
 *
 * @return              the character.
 */
char Alignment::getNucleotide(size_t i, size_t j) const
{
    // simply return
    return data_matrix[i][j];
}


/**
 * Get the number of sites/characters/columns for this alignment.
 *
 * @return              the number of sites.
 */
size_t Alignment::getNumberOfSites( void ) const
{
    // return our private variable for the number of sites
    return num_sites;
}


/**
 * Get the number of taxa/rows for this alignment.
 *
 * @return              the number of taxa.
 */
size_t Alignment::getNumberOfTaxa( void ) const
{
    // return our private variable for the number of taxa
    return num_taxa;
}


/**
 * Get the taxa names.
 *
 * @return              a vector of strings with the names of the taxa.
 */
const std::vector<std::string>& Alignment::getTaxonNames(void) const
{
    // return our private variable for the taxon names
    return taxon_names;
}


/**
 * Print the alignment to the given stream.
 * For simplicity, we will assume that the number of  character
 *
 */
void Alignment::print(std::ostream & o) const
{
    // first, we print some information about the alignment
    // print the number of sites
    o << "Number of sites = " << num_sites << '\n';
    o << "              ";

    // then print the index for each taxon
    for (int i=0; i<num_taxa; i++)
        o << std::setw(3) << i << " ";
    o << '\n';

    // we nicely separate these by '-'
    o << "------------------------";
    for (int i=0; i<num_taxa; i++)
        o << "---";
    o << '\n';

    // now we print on each line the column/site
    for (int j=0; j<num_sites; j++)
    {
        o << std::setw(10) << j+1 << " -- ";
        // so we iterate over all taxa to print the actual data matrix
        for (int i=0; i<num_taxa; i++)
        {
            o << std::setw(3) << data_matrix[i][j] << " ";
        }
        o << '\n';
    }

    // make sure to flush the stream so that it is printed.
    o.flush();
}


/**
 * Set the nucleotide for taxon i at site j.
 *
 * @param   x               The new nucleotide.
 * @param   i               The index of the taxon.
 * @param   j               The index of the site.
 */
void Alignment::setNucleotide(char x, size_t i, size_t j)
{
    // set the character of our internal data matrix
    data_matrix[i][j] = x;
}


/**
* Set the data matrix.
*
* @param   m               The new data matrix.
*/
void Alignment::setMatrix(const std::vector<std::vector<char> > &m)
{
    // set the internal variable
    data_matrix = m;
}


/**
* Set the taxon names.
*
* @param   n               A vector of strings with the new taxon names.
*/
void Alignment::setTaxonNames(const std::vector<std::string> &n)
{
    taxon_names = n;
}
