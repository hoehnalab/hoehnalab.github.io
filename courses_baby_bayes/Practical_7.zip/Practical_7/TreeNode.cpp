#include "TreeNode.h"


#include <stdio.h>
#include <iostream>

/**
 * Constructor of the tree node class.
 *
 * We initialize all variables with default values.
 *
 */
TreeNode::TreeNode( void ) :
    parent( NULL ),
    left( NULL ),
    right( NULL ),
    index( 0 ),
    age( 0.0 ),
    name( "" )
{
    
}


/**
 * Copy constructor of the tree node class.
 *
 * We need to make sure that we get a deep copy of the children.
 *
 * @param   tn              The object that we want to copy.
 */
TreeNode::TreeNode( const TreeNode& tn ) :
    parent( tn.parent ),
    left( NULL ),
    right( NULL ),
    index( tn.index ),
    age( tn.age ),
    name( tn.name )
{
    // only make a deep copy of the left child if it exists
    if ( tn.left != NULL )
    {
        left = new TreeNode( *tn.left );
        left->setParent( this );
    }
    // only make a deep copy of the right child if it exists
    if ( tn.right != NULL )
    {
        right = new TreeNode( *tn.right );
        right->setParent( this );
    }
}


/**
 * Destructor.
 *
 * We need to delete the children because the parent nodes own their children.
 */
TreeNode::~TreeNode( void )
{
    // delete both the left and right child.
    // it's actually safe to delete a pointer even it point to NULL
    delete left;
    delete right;
}


/**
 * Overloaded assignment operator.
 *
 * We need to free the memorythe children and make a deep copy.
 *
 * @param   tn              The object that we want to assign to us.
 * @return          The newly assigned object.
 */
TreeNode& TreeNode::operator=(const TreeNode& tn)
{
    // first, we need to check and avoid self-assignment
    if ( this != &tn )
    {
        // we are not assigning ourselves to us.
        // so let's free the memore first before we copy the new values
        delete left;
        delete right;
        
        // to be safe, set the pointer to NULL
        left  = NULL;
        right = NULL;
        
        // now we can copy over the values
        parent  = tn.parent;
        index   = tn.index;
        age     = tn.age;
        name    = tn.name;
   
        // only make a deep copy of the left child if it exists
        if ( tn.left != NULL )
        {
            left = new TreeNode( *tn.left );
            left->setParent( this );
        }
        // only make a deep copy of the right child if it exists
        if ( tn.right != NULL )
        {
            right = new TreeNode( *tn.right );
            right->setParent( this );
        }
        
        // we done now with our assignment
    }
    
    // we return this object now
    return *this;
}


/**
 * Get the age of this node.
 *
 * @return          Return the local variable that stores the age.
 */
double TreeNode::getAge( void ) const
{
    // simply return the local age variable
    return age;
}


/**
 * Get the branch length of this node.
 *
 * The branch length is computed by the age of the parent minus my own age.
 * If this is the root node, then we don't have parent, so no parent age.
 * By convention, we say that the root branch has a length of 0.0.
 *
 * @return          Return the branch length leading to this node.
 */
double TreeNode::getBranchLength( void ) const
{
    // check if this node has a parent, i.e., is not a root node.
    if ( parent != NULL )
    {
        // we do have a parent, so it's safe to compute the branch length
        // by the difference of my parent's age and my own age
        return parent->getAge() - age;
    }
    else
    {
        // otherwise, we return 0.0 by convention.
        return 0.0;
    }
}


/**
 * Get the index of this node.
 *
 * @return              The index for this node.
 */
int TreeNode::getIndex( void ) const
{
    // return the local variable for the index
    return index;
}


/**
 * Get the left child of this node.
 *
 * @return              The left child.
 */
const TreeNode* TreeNode::getLeftChild( void ) const
{
    // return the local variable for the left child node
    return left;
}


/**
 * Get the left child of this node. (non-const)
 *
 * @return              The left child.
 */
TreeNode* TreeNode::getLeftChild( void )
{
    // return the local variable for the left child node
    return left;
}


/**
 * Get the taxon name of this node.
 *
 * @return              The name of the node.
 */
const std::string& TreeNode::getName( void ) const
{
    // return the local variable for the name of this node
    // tip nodes will have the taxon name stored here.
    return name;
}


/**
 * Get the parent of this node.
 *
 * @return              The parent node.
 */
const TreeNode* TreeNode::getParent( void ) const
{
    // return the local variable for the parent node
    return parent;
}


/**
 * Get the parent of this node.  (non-const)
 *
 * @return              The parent node.
 */
TreeNode* TreeNode::getParent( void )
{
    // return the local variable for the parent node
    return parent;
}


/**
 * Get the right child of this node.
 *
 * @return              The right child.
 */
const TreeNode* TreeNode::getRightChild( void ) const
{
    // return the local variable for the right child
    return right;
}


/**
 * Get the right child of this node.  (non-const)
 *
 * @return              The right child.
 */
TreeNode* TreeNode::getRightChild( void )
{
    // return the local variable for the right child
    return right;
}


/**
 * Is this node a root node.
 *
 * @return              True if this node is a root node, false otherwise.
 */
bool TreeNode::isRoot( void ) const
{
    // this node is a root node if the parent node does not exist, i.e., is NULL
    return parent == NULL;
}


/**
 * Is this node a tip node?
 *
 * @return              True if both children don't exist, false otherwise.
 */
bool TreeNode::isTip( void ) const
{
    // check if either child node exists, i.e., is not NULL
    return left == NULL && right == NULL;
}


/**
 * Set the age of this node.
 *
 * @param   a               The new age of the node.
 */
void TreeNode::setAge(double a)
{
    // set the internal variable with the new age
    age = a;
}


/**
 * Set the left child of this node.
 *
 * @param   n               The new left child of the node.
 */
void TreeNode::setLeftChild(TreeNode* n)
{
    // first, we need to free the memory
    delete left;
    
    // set the internal variable with the new left child
    left = n;
}


/**
 * Set the index of this node.
 *
 * @param   i               The new index of the node.
 */
void TreeNode::setIndex(size_t i)
{
    // set the internal variable with the new index
    index = i;
}


/**
 * Set the name of this node.
 *
 * @param   n               The new name of the node.
 */
void TreeNode::setName(const std::string& n)
{
    // set the internal variable with the new name
    name = n;
}


/**
 * Set the parent of this node.
 *
 * @param   n               The new parent of the node.
 */
void TreeNode::setParent(TreeNode* n)
{
    // set the internal variable with the new parent
    parent = n;
}


/**
 * Set the right child of this node.
 *
 * @param   n               The new right child of the node.
 */
void TreeNode::setRightChild(TreeNode* n)
{
    // first, we need to free the memory
    delete right;
    
    // set the internal variable with the new right child
    right = n;
}
