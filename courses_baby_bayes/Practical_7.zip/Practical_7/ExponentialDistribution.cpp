#include "ExponentialDistribution.h"

#include <cmath>

ExponentialDistribution::ExponentialDistribution(const double *l) :
    lambda( l )
{

}


ExponentialDistribution::~ExponentialDistribution( void )
{
    // we do not own the value, so we do not delete it

}

double ExponentialDistribution::lnProbability( void ) const
{
    if ( *value < 0.0 ) return NAN;
    
    return (std::log(*lambda) - *lambda * *this->value);
}


double* ExponentialDistribution::rv(RandomNumberGenerator *rng)
{
    double l = *lambda;

    double u = rng->uniform01();
    return new double(-(1.0/l) * std::log(u));
}


void ExponentialDistribution::setValue(const double *v)
{
    value = v;
}
