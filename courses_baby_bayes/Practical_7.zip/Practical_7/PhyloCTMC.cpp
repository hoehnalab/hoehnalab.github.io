#include "PhyloCTMC.h"

#include "Alignment.h"
#include "RateMatrix_JC.h"
#include "Tree.h"
#include "TreeNode.h"

#include <cmath>

/**
 * Constructor of the PhyloCTMC.
 *
 * @param   phy         The phylogeny parameter.
 * @param   q           The rate matrix parameter.
 */
PhyloCTMC::PhyloCTMC(const Tree* phy, const RateMatrix_JC* q, const double* cr) :
    phylogeny( phy ),
    Q( q ),
    clock_rate( cr ),
    num_states( 4 )
{

}


/**
 * Destructor of the pure birth process.
 */
PhyloCTMC::~PhyloCTMC( void )
{
    // we do not own the rate parameter nor the value, so we have nothing to delete
}


void PhyloCTMC::computeLnLikelihoodRecursively(const TreeNode *node) const
{

    const TreeNode* left_child    = node->getLeftChild();
    const TreeNode* right_child   = node->getRightChild();

    if ( left_child != NULL && right_child != NULL ) //&& p->getIsClDirty() == true
    {

        std::vector<std::vector<double> > transition_probabilities_left   = std::vector<std::vector<double> >();
        std::vector<std::vector<double> > transition_probabilities_right  = std::vector<std::vector<double> >();
//        std::vector<std::vector<std::vector<double> > > transition_probabilities_left   = std::vector<std::vector<std::vector<double> > >(num_gamma_categories, std::vector<std::vector<double> >());
//        std::vector<std::vector<std::vector<double> > > transition_probabilities_right  = std::vector<std::vector<std::vector<double> > >(num_gamma_categories, std::vector<std::vector<double> >());

        size_t node_index           = node->getIndex();
        size_t left_child_index     = left_child->getIndex();
        size_t right_child_index    = right_child->getIndex();

        computeLnLikelihoodRecursively( left_child );
        computeLnLikelihoodRecursively( right_child );

        const std::vector< std::vector<double> >& cl_left     = conditional_likelihoods[active_likelihood_index[left_child_index] ][left_child_index ];
        const std::vector< std::vector<double> >& cl_right    = conditional_likelihoods[active_likelihood_index[right_child_index]][right_child_index];
              std::vector< std::vector<double> >& cl_node     = conditional_likelihoods[active_likelihood_index[node_index]       ][node_index       ];
//        const std::vector< std::vector< std::vector<double> > >& cl_left     = conditional_likelihoods[active_likelihood_index[left_child_index] ][left_child_index ];
//        const std::vector< std::vector< std::vector<double> > >& cl_right    = conditional_likelihoods[active_likelihood_index[right_child_index]][right_child_index];
//              std::vector< std::vector< std::vector<double> > >& cl_node     = conditional_likelihoods[active_likelihood_index[node_index]       ][node_index       ];

        transition_probabilities_left    = computeTransitionProbabilityMatrix(left_child);
        transition_probabilities_right   = computeTransitionProbabilityMatrix(right_child);
//        for (int k=0; k<num_gamma_categories; k++)
//        {
//            transition_probabilities_left[k]    = computeTransitionProbabilityMatrix(left_child,  k);
//            transition_probabilities_right[k]   = computeTransitionProbabilityMatrix(right_child, k);
//        }

        size_t num_sites = value->getNumberOfSites();
        for (size_t c=0; c<num_sites; c++)
        {
            const std::vector<double>& cl_left_site  = cl_left [c];
            const std::vector<double>& cl_right_site = cl_right[c];
                  std::vector<double>& cl_node_site  = cl_node [c];
//            const std::vector< std::vector<double> >& cl_left_site  = cl_left [c];
//            const std::vector< std::vector<double> >& cl_right_site = cl_right[c];
//                  std::vector< std::vector<double> >& cl_node_site  = cl_node [c];

//            for (size_t k=0; k<num_gamma_categories; k++)
//            {
//                const std::vector< double >& cl_left_sr     = cl_left_site [k];
//                const std::vector< double >& cl_right_sr    = cl_right_site[k];
//                      std::vector< double >& cl_node_sr     = cl_node_site [k];

                double sum_left = 0.0, sum_right = 0.0;

                for (size_t from=0; from<num_states; from++)
                {
                    sum_left    = 0.0;
                    sum_right   = 0.0;
                    for (size_t to=0; to<num_states; to++)
                    {
                        sum_left   += transition_probabilities_left [from][to] * cl_left_site [to];
                        sum_right  += transition_probabilities_right[from][to] * cl_right_site[to];
//                        sum_left   += transition_probabilities_left [k][from][to] * cl_left_sr [to];
//                        sum_right  += transition_probabilities_right[k][from][to] * cl_right_sr[to];
                    }
                    cl_node_site[from] = sum_left * sum_right;
//                    cl_node_sr[from] = sum_left * sum_right;
                }

//            }

        }

    }

}



std::vector<std::vector<double> > PhyloCTMC::computeTransitionProbabilityMatrix(const TreeNode *node) const
{
    double branch_length = node->getBranchLength();
    double c = 1.0;
    if ( clock_rate != NULL)
    {
        c = *clock_rate;
    }
//    double alpha = 1E20;
//    if ( alpha_asrv != NULL )
//    {
//        alpha = *alpha_asrv;
//    }
//    double q = (cat_index+0.5) / double(num_gamma_categories);
//    double site_rate = Statistics::Gamma::quantile(alpha, alpha, q);
//    double rate = c * site_rate;
    double rate = c;

    return Q->calculateTransitionProbabilities(branch_length, rate);
}



void PhyloCTMC::initializeConditionalLikelihoods( void )
{

    const Alignment& alignment = *value;

    // allocate conditional likelihoods
    size_t n_nodes          = 2 * alignment.getNumberOfTaxa()-1;
    size_t n_sites          = alignment.getNumberOfSites();



    conditional_likelihoods = std::vector< std::vector<std::vector< std::vector< double > > > >( 2,
                                std::vector< std::vector< std::vector< double> > >( n_nodes,
                                    std::vector< std::vector< double> >(n_sites,
                                        std::vector< double >( num_states, 0) ) ) );

//    conditional_likelihoods = std::vector< std::vector< std::vector<std::vector< std::vector< double > > > > >( 2,
//                                std::vector< std::vector< std::vector< std::vector< double> > > >( n_nodes,
//                                    std::vector< std::vector< std::vector< double> > >(n_sites,
//                                        std::vector< std::vector< double > >( num_gamma_categories,
//                                            std::vector< double >( num_states, 0) ) ) ) );

    // initialize the tip conditional likelihoods
    for (int i=0; i<alignment.getNumberOfTaxa(); i++)
    {
        std::vector< std::vector<double> >& cl_0 = conditional_likelihoods[0][i];
        std::vector< std::vector<double> >& cl_1 = conditional_likelihoods[1][i];
//        std::vector< std::vector< std::vector<double> > >& cl_0 = conditional_likelihoods[0][i];
//        std::vector< std::vector< std::vector<double> > >& cl_1 = conditional_likelihoods[1][i];
        for (int j=0; j<n_sites; j++)
        {
            std::vector<double>& cl_0_site = cl_0[j];
            std::vector<double>& cl_1_site = cl_1[j];
//            std::vector< std::vector<double> >& cl_0_site = cl_0[j];
//            std::vector< std::vector<double> >& cl_1_site = cl_1[j];
            char nuc = alignment.getNucleotide(i, j);
            std::vector<int> states = alignment.getNucleotideStates(nuc);
//            for (int k=0; k<num_gamma_categories; k++)
//            {
//                std::vector<double>& cl_0_sr = cl_0_site[k];
//                std::vector<double>& cl_1_sr = cl_1_site[k];

                for (int s=0; s<num_states; s++)
                {
                    cl_0_site[s] = (double)states[s];
                    cl_1_site[s] = (double)states[s];
//                    cl_0_sr[s] = (double)states[s];
//                    cl_1_sr[s] = (double)states[s];
                }
//            }
        }
    }

    active_likelihood_index = std::vector<size_t>(n_nodes,0);
}



/**
 * Compute the log-probability of the values given the CTMC process.
 *
 * More soon ...
 *
 * @return              Returns the log-probability.
 */
double PhyloCTMC::lnProbability( void ) const
{
    // initialize the log probability
    double ln_prob = 0.0;

    // we will add code here next week
    const TreeNode *root = phylogeny->getRootNode();
    size_t root_index = root->getIndex();

    // start the computation of the conditional likelihoods recursively
    computeLnLikelihoodRecursively( root );

//    Simplex f( num_states );
    std::vector<double> f = std::vector<double>(num_states, 1.0/num_states);

    //    const Simplex &f = *stationary_frequencies->getValue();
    const std::vector< std::vector<double> >& cl_node = conditional_likelihoods[active_likelihood_index[root_index] ][root_index];
//    double category_prob = 1.0 / num_gamma_categories;

    size_t num_sites = value->getNumberOfSites();
    for (size_t c=0; c<num_sites; c++)
    {
        double site_prob = 0.0;

        const std::vector<double>& cl_site = cl_node[c];

//        for (size_t i=0; i<num_gamma_categories; i++)
//        {
//            const std::vector<double>& cl_sr = cl_site[i];

            for (size_t j=0; j<num_states; j++)
            {
                site_prob += cl_site[j] * f[j];
            }
//            site_prob *= category_prob;
//        }

        ln_prob += log(site_prob);
    }

    // return the computed log probability
    return ln_prob;
}


/**
 * Draw a random alignment from a CTMC process along the pylogeny.
 *
 * @param   rng         The random number generator used for the simulation.
 * @return              The random alignment.
 */
Alignment* PhyloCTMC::rv(RandomNumberGenerator *rng)
{
    // we assume a rooted phylogeny with 2*n-1 nodes
    size_t num_taxa  = (phylogeny->getNumberOfNodes()+1) / 2;
    size_t num_sites = 100;

    // create an empty alignment
    Alignment* a = new Alignment( num_taxa, num_sites );
    std::vector<std::vector<char> > data_matrix = std::vector<std::vector<char> >( num_taxa, std::vector<char>(num_sites, '?') );

    // now we want to start our simulation for the root node
    // so we need to get the root node first
    const TreeNode* root = phylogeny->getRootNode();
    // create and empty sequence
    std::vector<char> root_sequence = std::vector<char>(num_sites, '?');
    // and then simulate each character from the prior
    // the prior under the model are the stationary frequencies,
    // which are all 1/4 for the Jukes-Cantor model
    for ( size_t i=0; i<num_sites; i++ )
    {
        double u = rng->uniform01();
        if ( u < 0.25 )
        {
            root_sequence[i] = 'A';
        }
        else if ( u < 0.5 )
        {
            root_sequence[i] = 'C';
        }
        else if ( u < 0.75 )
        {
            root_sequence[i] = 'G';
        }
        else
        {
            root_sequence[i] = 'T';
        }
    }

    // simulate the sequence along the left and right branches of the root
    simulateAlignmentRecursively( data_matrix, root_sequence, root->getLeftChild(), rng );
    simulateAlignmentRecursively( data_matrix, root_sequence, root->getRightChild(), rng );

    // collect the taxon names
    // we start with an empty vector
    std::vector<std::string> names = std::vector<std::string>(num_taxa, "");
    // then we get all nodes on ask for the names of the tips
    const std::vector<TreeNode*>& nodes = phylogeny->getNodes();
    for (size_t i=0; i<num_taxa; i++)
    {
        names[i] = nodes[i]->getName();
    }

    // fill the alignment with data
    a->setTaxonNames( names );
    a->setMatrix( data_matrix );


    // and return the new alignment
    return a;
}



void PhyloCTMC::setValue(const Alignment *x)
{
    value = x;

    initializeConditionalLikelihoods();
}


/**
 * Draw a random alignment from a CTMC process along the pylogeny.
 *
 * @param   rng         The random number generator used for the simulation.
 */
void PhyloCTMC::simulateAlignmentRecursively( std::vector<std::vector<char> >& data, const std::vector<char>& parent_sequence, const TreeNode* node, RandomNumberGenerator *rng )
{

    size_t num_sites = parent_sequence.size();

    // create and empty sequence
    std::vector<char> sequence = std::vector<char>(num_sites, '?');

    double time = node->getBranchLength();
    std::vector<std::vector<double> > P = Q->calculateTransitionProbabilities(time, 1.0);

    // and then simulate each character using the transition probabilities
    for ( size_t i=0; i<num_sites; i++ )
    {
        // first, we need to get the transition probabilities for this starting character
        std::vector<double> this_transition_probability;

        switch (parent_sequence[i])
        {
            case 'A':
                this_transition_probability = P[0];
                break;

            case 'C':
                this_transition_probability = P[1];
                break;

            case 'G':
                this_transition_probability = P[2];
                break;

            case 'T':
                this_transition_probability = P[3];
                break;

            default:
                break;
        }

        // simulate the
        double u = rng->uniform01();
        if ( u < this_transition_probability[0] )
        {
            sequence[i] = 'A';
        }
        else if ( u < (this_transition_probability[0]+this_transition_probability[1]) )
        {
            sequence[i] = 'C';
        }
        else if ( u < (this_transition_probability[0]+this_transition_probability[1]+this_transition_probability[2]) )
        {
            sequence[i] = 'G';
        }
        else
        {
            sequence[i] = 'T';
        }
    }

    // finally, we need to set the sequence into the data matrix (if this node is a tip node)
    // or continue with the recursive simulation if this is an interior node
    if ( node->isTip() )
    {
        data[ node->getIndex() ] = sequence;
    }
    else
    {
        simulateAlignmentRecursively( data, sequence, node->getLeftChild(), rng );
        simulateAlignmentRecursively( data, sequence, node->getRightChild(), rng );
    }


}
