#ifndef Model_h
#define Model_h

#include <stdio.h>
#include <vector>

// forward declarations
class Alignment;
class ExponentialDistribution;
class PhyloCTMC;
class PureBirthProcess;
class RateMatrix_JC;
class Tree;
class UniformDistribution;

/**
 * \class Model
 *
 * \brief This class represents the phylogenetic model.
 *
 *
 *
 * \author Sebastian Höhna
 *
 */
class Model {

public:

    Model(const std::string &fn);
    virtual                                        ~Model();

    // parameters
    double                                          getBirthRate(void) const;
    double                                          getClockRate(void) const;

//    void                                            setAlignment( Alignment* r );
    void                                            setBirthRate( double r );
    void                                            setClockRate( double r );
//    void                                            setRateMatrix( RateMatrix_JC* q );
//    void                                            setTree( Tree* r );

    // distributions
    double                                          getBirthRatePrior(void);
    double                                          getClockRatePrior(void);
    double                                          getLikelihood(void);
    double                                          getTreePrior(void);

private:

    Alignment*                                      my_alignment;
    double*                                         my_birth_rate;
    double*                                         my_clock_rate;
    RateMatrix_JC*                                  my_rate_matrix;
    Tree*                                           my_tree;

    PureBirthProcess*                               tree_prior;
    ExponentialDistribution*                        birth_rate_prior;
    UniformDistribution*                            clock_rate_prior;
    PhyloCTMC*                                      likelihood;


};

#endif /* Model_h */
