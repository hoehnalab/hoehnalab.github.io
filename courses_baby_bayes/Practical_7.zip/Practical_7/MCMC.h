#ifndef MCMC_h
#define MCMC_h

#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>


#include "Model.h"
#include "RandomNumberGenerator.h"

// forward declarations

/**
 * \class MCMC
 *
 * \brief This class represents the MCMC algorithm.
 *
 *
 *
 * \author Sebastian Höhna
 *
 */
class MCMC {

public:

    MCMC(const std::string& filename);
    MCMC(const MCMC& m);
    virtual                                        ~MCMC();

    void                                            run(int n_gen);

private:
    // our moves
    void                                            monitorParameters(int g);
    void                                            updateBirthRate(void);
    void                                            updateClockRate(void);

    Model                                           my_model;
    RandomNumberGenerator                           rng;
    std::ofstream                                   parameter_file;
    std::ofstream                                   tree_file;

};

#endif /* MCMC_h */
