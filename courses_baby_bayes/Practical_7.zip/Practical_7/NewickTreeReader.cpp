#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <iostream>
#include <sstream>

#include "NewickTreeReader.h"
#include "Tree.h"
#include "TreeNode.h"



/**
 * Default constructor.
 *
 * The default constructor does nothing except allocating the object.
 */
NewickTreeReader::NewickTreeReader()
{
    
}



/**
 * Read all trees in the file which should be in Newick tree format.
 *
 * @param   fn          The filename.
 * @return              A vector with all the trees read from the file.
 */
std::vector<Tree> NewickTreeReader::readTrees(const std::string& fn)
{
        
    // open the file and create a file input stream
    std::ifstream inFile( fn );

    // check if we were successful in opening the file
    if ( !inFile )
    {
        // the file could not be opened
        std::cerr << "Could not open file \"" << fn << "\"" << std::endl;
    }
    
    // initialize the vector of trees
    // we will fill these later
    std::vector<Tree> trees = std::vector<Tree>();
    
    // now loop over each line in the file
    while ( inFile.good() )
    {
        // create a string variable that will hold the line
        std::string line;
        
        // read a line
        getline(inFile, line);

        // skip empty lines
        if (line.length() == 0)
        {
            continue;
        }
        // note that we assume here for simplicity that our Newick trees don't contain spaces.
        // you may want to remove all spaces ...
        
        // construct the tree by calling the create tree from Newick string function
        TreeNode *root = createTreeFromNewick( line );
        
        // create and allocate the tree object
        Tree t =  Tree( root );
        
        // add the tree to our vector
        trees.push_back( t );
    }
    
    // finally, return the vector of trees
    return trees;
}


/**
 * Create a tree from a Newick string.
 *
 * @param   newick      The tree as a Newick string.
 * @return              The root node of the create tree.
 */
TreeNode* NewickTreeReader::createTreeFromNewick(const std::string& newick)
{
    // break the string into its component parts
    std::vector<std::string> tokens = parseNewickString(newick);
    
    // we need some variables
    // first, if the last token was a ':' so that we next read in the branch length
    bool reading_branch_length = false;
    // we also need a pointer to the ancestor
    TreeNode* ancestor  = NULL;
    // and also a pointer to the root for checking that the algorithm worked correctly
    TreeNode* root      = NULL;
    
    // build up the tree from the parsed Newick string
    for (int i=0; i<tokens.size(); i++)
    {
        // get the current token
        const std::string& token = tokens[i];

        // check what the token corresponds to
        if (token == "(")
        {
            // we go one level deeper into the tree with a '('
            // create new node
            TreeNode* next_node = new TreeNode();
            // if this was the first '(', then we need to initialize the root
            if (ancestor == NULL)
            {
                root = next_node;
            }
            else
            {
                // we have an ancestral node for this new node
                // so we set the it as the parent
                next_node->setParent(ancestor);
                // and the new node will be either the left or right child
                if (ancestor->getLeftChild() == NULL)
                {
                    ancestor->setLeftChild(next_node);
                }
                else
                {
                    ancestor->setRightChild(next_node);
                }
            }
            // now we set the new node as the next ancestor
            ancestor = next_node;
        }
        else if (token == ")" || token == ",")
        {
            // we finished with the previous node
            // move one level back
            // for safety, check that we can do so
            if (ancestor->getParent() == NULL)
            {
                std::cout << "Error: We cannot find an expected ancestor" << std::endl;
                exit(1);
            }
            // we will reset the ancestor as the ancestor's parent
            ancestor = ancestor->getParent();
        }
        else if (token == ":")
        {
            // begin reading a branch length
            reading_branch_length = true;
        }
        else if (token == ";")
        {
            // finished!
            // just make sure that we also terminated at the root
            if (ancestor != root)
            {
                std::cout << "Error: We expect to finish at the root node" << std::endl;
                exit(1);
            }
        }
        else
        {
            // we have a taxon name or a branch length
            if (reading_branch_length == true)
            {
                // convert the token into a double
                double x = std::stod(token);
                // since we are actually storing ages, we compute the age as
                // the child's age plus the branch length.
                // thus, we set the age of the parent/ancestor and need to make sure that we have one
                if ( ancestor->getParent() != NULL )
                {
                    ancestor->getParent()->setAge( ancestor->getAge() + x );
                }
                // now flip back the bool that we are not expecting a branch length anymore
                reading_branch_length = false;
            }
            else
            {
                // we got a new tip node
                // create this tip
                TreeNode* next_node = new TreeNode();
                // and tell it who its parent was
                next_node->setParent(ancestor);
                // also tell the ancestor that this was a left/right child
                if ( ancestor->getLeftChild() == NULL)
                {
                    ancestor->setLeftChild(next_node);
                }
                else
                {
                    ancestor->setRightChild(next_node);
                }
                // also set the name of the tip
                next_node->setName(token);
                // and reset, as usual, reset the ancestor to be the current node
                ancestor = next_node;
            } // finished the if-else for the taxon name vs branch length
            
        } // finished the if-else for what type of token it was
        
    } // finished the foor loop over all tokens
    
    // return the root node for this tree
    return root;
}


/**
 * Parse the Newick string into separate tokens.
 *
 * A token is separated by a '(', ')', ',', ':' or ','
 *
 * @param   ns          The newick string that we want to parse.
 * @return              A vector of strings containing all the tokens and separators.
 */
std::vector<std::string> NewickTreeReader::parseNewickString(const std::string& ns)
{
    // create an empty vector of strings for the tokens
    std::vector<std::string> tks;

    // now we iterate over each character in the string
    for (int i=0; i<ns.size(); i++)
    {
        // get the current character of the string
        char c = ns[i];
        
        // check if it was on of the separators
        if (c == '(' || c == ')' || c == ',' || c == ':' || c == ';')
        {
            // add the separator-token to our vector
            tks.push_back( std::string(1,c) );
        }
        else
        {
            // it was not a separator, so it was actually some token
            // we need to extract it until the next separator
            // we move over the string until we hit the next separator
            int j = i;
            // create
            std::string temp_token = "";
            while ( !(c == '(' || c == ')' || c == ',' || c == ':' || c == ';') )
            {
                // add the current character to our token string
                temp_token += c;
                // move the index forward
                j++;
                // get the next character
                c = ns[j];
            }
            // fast forward the index of the newick string
            i = j-1;
            // add the token to our vector
            tks.push_back(temp_token);
        }
        
    } // end for loop over all characters in the string
    
    // return the vector of tokens
    return tks;
}
