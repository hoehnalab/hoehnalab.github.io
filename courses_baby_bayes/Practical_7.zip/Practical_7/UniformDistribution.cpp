#include "UniformDistribution.h"

#include <cmath>

UniformDistribution::UniformDistribution(const double *mi, const double* ma) :
    min( mi ),
    max( ma )
{

}


UniformDistribution::~UniformDistribution( void )
{
    // we do not own the value, so we do not delete it

}

double UniformDistribution::lnProbability( void ) const
{
    if ( *value < *min || *value > *max ) return NAN;

    return -log( *max - *min );
}


double* UniformDistribution::rv(RandomNumberGenerator *rng)
{
    double mi = *min;
    double ma = *max;

    double u = rng->uniform01();
    return new double( u * (ma - mi) + mi );
}


void UniformDistribution::setValue(const double *v)
{
    value = v;
}
