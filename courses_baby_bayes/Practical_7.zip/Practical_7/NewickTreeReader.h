#ifndef NewickTreeReader_H
#define NewickTreeReader_H

#include <string>
#include <vector>

class Tree;
class TreeNode;
    
/**
 * Newick tree reader.
 *
 * The newick tree reader provides convenience methods for reading trees in Newick format.
 *
 *
 *
 */
class NewickTreeReader {
        
public:
    NewickTreeReader();
    
    std::vector<Tree>                   readTrees(const std::string &fn);

private:
    TreeNode*                           createTreeFromNewick(const std::string& newick);
    std::vector<std::string>            parseNewickString(const std::string& ns);

};


#endif
