#include <iostream>

#include "MCMC.h"

int main (int argc, char* argv[]) {

    // print header
    std::cout << "           BabyBayes v1.0                " << std::endl;
    std::cout << "                                         " << std::endl;
    std::cout << "                by                       " << std::endl;
    std::cout << "                                         " << std::endl;
    std::cout << "           Sebastian Höhna               " << std::endl;
    std::cout << "  Ludwig-Maximilians-Universität München " << std::endl;
    std::cout << "                                         " << std::endl;
    std::cout << "                and                      " << std::endl;
    std::cout << "                                         " << std::endl;
    std::cout << "          John Huelsenbeck               " << std::endl;
    std::cout << "    University of California, Berkeley   " << std::endl;
    std::cout << "                                         " << std::endl;
    std::cout << "                                         " << std::endl;

    MCMC my_mcmc = MCMC("primates.phy");
    my_mcmc.run( 1000 );

    return 0;
}
