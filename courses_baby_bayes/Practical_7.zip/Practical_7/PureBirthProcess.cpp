#include "PureBirthProcess.h"

#include "Tree.h"
#include "TreeNode.h"

#include <cmath>
#include <iostream>

PureBirthProcess::PureBirthProcess(const std::vector<std::string> &n, const double *b) :
    taxon_names( n ),
    birth_rate( b )
{
//    value = rv();
}



PureBirthProcess::~PureBirthProcess( void )
{

}


double PureBirthProcess::lnProbability( void ) const
{
    double ln_prob = 0.0;

    double l = *birth_rate;
    const std::vector<TreeNode*> &nodes = value->getNodes();
    for (size_t i=0; i<nodes.size(); i++)
    {
        TreeNode *node = nodes[i];
        if ( node->isRoot() == false )
        {
            double bl = node->getBranchLength();
            ln_prob += (std::log(l) - l * bl);
//            ln_prob += std::log( i+1 );
        }
    }

    return ln_prob;
}


Tree* PureBirthProcess::rv(RandomNumberGenerator *rng)
{
    double l = *birth_rate;
    double num_taxa = taxon_names.size();

    std::vector<TreeNode*> active;
    std::vector<TreeNode*> inactive;
    std::vector<double> times;

    TreeNode *root = new TreeNode();
    TreeNode *left = new TreeNode();
    left->setParent( root );
    root->setLeftChild( left );
    TreeNode *right = new TreeNode();
    right->setParent( root );
    root->setRightChild( right );

    active.push_back(left);
    active.push_back(right);
    inactive.push_back(root);
    times.push_back( 0.0 );

    double current_time = 0.0;
    while ( active.size() < taxon_names.size() )
    {
        // randomly draw a new speciation event
        double rate = l*active.size();
        double u = rng->uniform01();
        double next_time = current_time - (1.0/rate) * std::log(u);
        times.push_back( next_time );

        // randomly pick a node
        size_t index = rng->uniform01() * active.size();
        TreeNode *node = active[index];

        TreeNode *left = new TreeNode();
        left->setParent( node );
        node->setLeftChild( left );
        TreeNode *right = new TreeNode();
        right->setParent( node );
        node->setRightChild( right );

        // now remove the current node and add it's two children to our active list
        active.erase( active.begin() + index );
        active.push_back( left );
        active.push_back( right );

        // for later use, store the current node
        inactive.push_back( node );

        current_time = next_time;
    }

    double rate = l*active.size();
    double u = rng->uniform01();
    double next_event = -(1.0/rate) * std::log(u);
    double v = rng->uniform01();
    double tree_age = current_time + next_event*v;

    for ( size_t i=0; i<inactive.size(); i++ )
    {
        TreeNode *node = inactive[i];
        node->setAge( tree_age - times[i] );
        node->setIndex( 2*num_taxa-2-i );
    }

    for ( size_t i=0; i<taxon_names.size(); i++ )
    {

        // randomly pick a node
        size_t index = rng->uniform01() * active.size();
        TreeNode *node = active[index];
        active.erase( active.begin() + index );

        node->setIndex( i );
        node->setName( taxon_names[i] );
    }

    Tree *t = new Tree( root );

    return t;
}


void PureBirthProcess::setValue(const Tree *t)
{
    value = t;
}
