#include "MCMC.h"

#include <math.h>       /* isnan, sqrt */


MCMC::MCMC( const std::string &filename ) :
    my_model( filename ),
    parameter_file( "my_analysis.log" ),
    tree_file( "my_analysis.trees" )
{

}

MCMC::MCMC( const MCMC &m ) :
    my_model( "" ),
    parameter_file( "my_analysis.log" ),
    tree_file( "my_analysis.trees" )
{

}


MCMC::~MCMC( void )
{
    // nothing to do here
}



void MCMC::monitorParameters( int gen )
{
    parameter_file << gen;
    parameter_file << "\t";
    parameter_file << my_model.getBirthRate();
    parameter_file << "\t";
    parameter_file << my_model.getClockRate();
    parameter_file << "\t";
    parameter_file << std::endl;
}

void MCMC::updateBirthRate( void )
{
    // get the current birth rate
    double current_rate = my_model.getBirthRate();

    // draw a new random uniform number
    double u = rng.uniform01();

    // define the window size
    double delta = 7.32;

    // now we compute the new proposed values
    double new_rate = current_rate + (u-0.5) * delta;

    // compute the prior ratio and likelihood ratio
    double current_prior = my_model.getBirthRatePrior();
    double current_likelihood = my_model.getTreePrior();

    // set the new value
    my_model.setBirthRate( new_rate );

    double new_prior = my_model.getBirthRatePrior();
    double new_likelihood = my_model.getTreePrior();

    double acceptance_prob = new_prior - current_prior + new_likelihood - current_likelihood;

    u = rng.uniform01();

    if ( isnan(acceptance_prob) || u > acceptance_prob )
    {
        // reject -> reset the value
        my_model.setBirthRate( current_rate );
    }
    else
    {
        // accept! nothing to do, because we changed our value already
    }


}



void MCMC::updateClockRate( void )
{
}


void MCMC::run( int num_generations )
{
    // we assume that the model and all parameters are initialized.

    int thinning = 10;

    for ( int current_gen=0; current_gen<num_generations; current_gen++ )
    {
        // draw new values:
        updateBirthRate();

        updateClockRate();

        // now we monitor the variables
        if ( current_gen % thinning == 0 )
        {
            monitorParameters( current_gen );
        }

    }

    std::cout << "Hooray, we finished our MCMC run!" << std::endl;
}
