#ifndef Tree_h
#define Tree_h

#include <vector>
#include <string>

// forward declaration of the class TreeNode
class TreeNode;

/**
 * \class Tree
 *
 * \brief The phylogenetic tree class.
 *
 * This class represent the phylogenetic tree.
 * The main structure is actually stored in the TreeNode itself.
 * Here we store the root node and for convenience also a vector of all nodes.
 *
 *
 * \author Sebastian Höhna
 *
 */
class Tree {
    
public:
    Tree(TreeNode* r);
    Tree(const Tree& t);
    ~Tree(void);
    
    Tree&                               operator=(const Tree& t);

    std::string                         getNewickRepresentation(void) const;
    const std::vector<TreeNode*>        getNodes(void) const;
    size_t                              getNumberOfNodes(void) const;
    const TreeNode*                     getRootNode(void) const;
    
private:
    std::string                         computeNewickRecursively(const TreeNode& n) const;
    void                                fillNodesByPhylogeneticTraversal(TreeNode* node);

    TreeNode*                           root;
    std::vector<TreeNode*>              nodes;
    
};


#endif /* Tree_h */
