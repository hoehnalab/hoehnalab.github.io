#ifndef PureBirthProcess_h
#define PureBirthProcess_h

#include <stdio.h>

#include "RandomNumberGenerator.h"


// forward declaration(s)
class Tree;


class PureBirthProcess {
    
public:
    PureBirthProcess(const std::vector<std::string> &n, const double *b);
    virtual                    ~PureBirthProcess();
    
    double                      lnProbability(void) const ;
    Tree*                       rv(RandomNumberGenerator *rng);
    void                        setValue(const Tree *x);
    
protected:
    
    std::vector<std::string>    taxon_names;
    const double*               birth_rate;
    const Tree*                 value;

};

#endif /* PureBirthProcess_h */
