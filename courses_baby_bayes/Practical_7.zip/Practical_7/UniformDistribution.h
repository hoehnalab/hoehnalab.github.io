#ifndef UniformDistribution_h
#define UniformDistribution_h

#include <stdio.h>

#include "RandomNumberGenerator.h"

class UniformDistribution {

public:
    UniformDistribution(const double* mi, const double* ma);
    virtual                    ~UniformDistribution();

    double                      lnProbability(void) const ;
    double*                     rv(RandomNumberGenerator* rng);
    void                        setValue(const double *x);

protected:

    const double*               min;
    const double*               max;
    const double*               value;

};


#endif /* UniformDistribution_hpp */
