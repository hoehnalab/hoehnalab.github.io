#ifndef RateMatrix_JC_h
#define RateMatrix_JC_h

#include <stdio.h>
#include <vector>

/**
 * \class RateMatrix_JC
 *
 * \brief Represents the rate matrix class for the Jukes-Cantor (1969) model.
 *
 * This class provides the transition probability calculation using for the Jukes-Cantor (1969) rate matrix.
 * The purpose is simply to calculate these transition probabilities for a given branch length.
 * For the Jukes-Cantor rate matrix we know the analytical solution for the transition probabilities.
 * The JC has no parameter but can be applied to any number of states.
 * The resulting rate matrix is computed by:
 *
 *      |   -     1/3    1/3    1/3  |
 *      |                            |
 *      |  1/3     -     1/3    1/3  |
 * Q =  |                            |
 *      |  1/3    1/3     -     1/3  |
 *      |                            |
 *      |  1/3    1/3    1/3     -   |
 *
 *
 * \author Sebastian Höhna
 *
 */
class RateMatrix_JC {
    
public:

    RateMatrix_JC();
    virtual                                        ~RateMatrix_JC();
    
    std::vector<std::vector<double> >               calculateTransitionProbabilities(double time, double rate) const;       //!< Calculate the transition matrixmatrix
 
};

#endif /* RateMatrix_JC_h */
